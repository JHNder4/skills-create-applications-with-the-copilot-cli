import { motion } from "motion/react";
import { ShoppingBag } from "lucide-react";

interface HomeScreenProps {
  onStartOrder: () => void;
}

export function HomeScreen({ onStartOrder }: HomeScreenProps) {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="flex flex-col items-center justify-center min-h-screen p-6 bg-gradient-to-b from-background to-secondary"
    >
      <motion.div
        initial={{ scale: 0.8, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ delay: 0.2, type: "spring", stiffness: 100 }}
        className="mb-12 text-center"
      >
        <h1 className="text-6xl font-bold mb-4 bg-gradient-to-r from-primary to-muted-foreground bg-clip-text text-transparent">
          Thepoint
        </h1>
        <p className="text-muted-foreground text-lg">Premium Delivery Experience</p>
      </motion.div>

      <motion.button
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 0.4 }}
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
        onClick={onStartOrder}
        className="w-full max-w-md px-8 py-6 bg-primary text-primary-foreground rounded-2xl shadow-2xl hover:shadow-primary/20 transition-all duration-300 flex items-center justify-center gap-3"
      >
        <ShoppingBag className="w-6 h-6" />
        <span className="text-xl">Hacer pedido</span>
      </motion.button>

      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.6 }}
        className="mt-8 text-center text-muted-foreground text-sm"
      >
        Rápido • Elegante • Premium
      </motion.div>
    </motion.div>
  );
}
