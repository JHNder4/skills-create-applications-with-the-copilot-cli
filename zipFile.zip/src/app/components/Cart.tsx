import { motion } from "motion/react";
import { ArrowLeft, MapPin } from "lucide-react";

export interface Product {
  id: string;
  name: string;
  price: number;
  image?: string;
}

interface CartProps {
  products: Product[];
  cart: Record<string, number>;
  onBack: () => void;
  onContinue: () => void;
}

export function Cart({ products, cart, onBack, onContinue }: CartProps) {
  const cartItems = products
    .map(product => ({
      ...product,
      quantity: cart[product.id] || 0,
    }))
    .filter(item => item.quantity > 0);

  const total = cartItems.reduce((sum, item) => sum + item.price * item.quantity, 0);

  return (
    <motion.div
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: -20 }}
      className="min-h-screen bg-background p-6"
    >
      <div className="max-w-2xl mx-auto">
        <motion.button
          whileHover={{ x: -5 }}
          whileTap={{ scale: 0.95 }}
          onClick={onBack}
          className="mb-6 flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors"
        >
          <ArrowLeft className="w-5 h-5" />
          <span>Volver</span>
        </motion.button>

        <motion.div
          initial={{ y: -20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          className="mb-8"
        >
          <h2 className="text-3xl font-bold mb-2">Tu Carrito</h2>
          <p className="text-muted-foreground">Revisa tu pedido</p>
        </motion.div>

        <div className="space-y-4 mb-8">
          {cartItems.map((item, index) => (
            <motion.div
              key={item.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="bg-card border border-border rounded-2xl p-6 shadow-lg"
            >
              <div className="flex items-center justify-between">
                <div className="flex-1">
                  <h3 className="text-lg font-semibold mb-1">{item.name}</h3>
                  <p className="text-muted-foreground">Cantidad: {item.quantity}</p>
                </div>
                <div className="text-right">
                  <p className="text-xl font-bold text-primary">
                    ${item.price * item.quantity}
                  </p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.3 }}
          className="bg-secondary border border-border rounded-2xl p-6 mb-8 shadow-lg"
        >
          <div className="flex items-center justify-between mb-2">
            <span className="text-muted-foreground">Subtotal</span>
            <span className="font-semibold">${total}</span>
          </div>
          <div className="flex items-center justify-between text-sm mb-4">
            <span className="text-muted-foreground">Método de pago</span>
            <span className="font-semibold">Efectivo</span>
          </div>
          <div className="border-t border-border pt-4">
            <div className="flex items-center justify-between">
              <span className="text-xl font-bold">Total</span>
              <span className="text-2xl font-bold text-primary">${total}</span>
            </div>
          </div>
        </motion.div>

        <motion.button
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.4 }}
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
          onClick={onContinue}
          className="w-full px-6 py-4 bg-primary text-primary-foreground rounded-2xl shadow-xl hover:shadow-primary/20 transition-all duration-300 flex items-center justify-center gap-3"
        >
          <MapPin className="w-5 h-5" />
          <span>Continuar a ubicación</span>
        </motion.button>
      </div>
    </motion.div>
  );
}
