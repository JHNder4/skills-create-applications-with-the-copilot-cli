import { motion } from "motion/react";
import { CheckCircle2, MessageCircle, Home } from "lucide-react";

export interface Product {
  id: string;
  name: string;
  price: number;
  image?: string;
}

interface OrderConfirmationProps {
  products: Product[];
  cart: Record<string, number>;
  address: string;
  onSendWhatsApp: () => void;
  onBackToHome: () => void;
}

export function OrderConfirmation({
  products,
  cart,
  address,
  onSendWhatsApp,
  onBackToHome,
}: OrderConfirmationProps) {
  const cartItems = products
    .map(product => ({
      ...product,
      quantity: cart[product.id] || 0,
    }))
    .filter(item => item.quantity > 0);

  const total = cartItems.reduce((sum, item) => sum + item.price * item.quantity, 0);

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.95 }}
      className="min-h-screen bg-background p-6 flex items-center justify-center"
    >
      <div className="max-w-2xl w-full">
        <motion.div
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ delay: 0.2, type: "spring", stiffness: 200 }}
          className="flex justify-center mb-8"
        >
          <div className="w-20 h-20 bg-primary/10 rounded-full flex items-center justify-center">
            <CheckCircle2 className="w-12 h-12 text-primary" />
          </div>
        </motion.div>

        <motion.div
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.3 }}
          className="text-center mb-8"
        >
          <h2 className="text-3xl font-bold mb-2">¡Pedido listo!</h2>
          <p className="text-muted-foreground">
            Confirma tu pedido enviándolo por WhatsApp
          </p>
        </motion.div>

        <motion.div
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.4 }}
          className="bg-card border border-border rounded-2xl p-6 mb-6 shadow-lg"
        >
          <h3 className="font-semibold mb-4">Resumen del pedido</h3>
          <div className="space-y-3 mb-4">
            {cartItems.map(item => (
              <div key={item.id} className="flex justify-between text-sm">
                <span className="text-muted-foreground">
                  {item.name} x{item.quantity}
                </span>
                <span className="font-semibold">${item.price * item.quantity}</span>
              </div>
            ))}
          </div>
          <div className="border-t border-border pt-4 mb-4">
            <div className="flex justify-between">
              <span className="font-semibold">Total</span>
              <span className="text-xl font-bold text-primary">${total}</span>
            </div>
          </div>
          <div className="border-t border-border pt-4 space-y-2 text-sm">
            <div className="flex justify-between">
              <span className="text-muted-foreground">Dirección de entrega</span>
            </div>
            <p className="text-foreground">{address}</p>
            <div className="flex justify-between mt-4">
              <span className="text-muted-foreground">Método de pago</span>
              <span className="font-semibold">Efectivo</span>
            </div>
          </div>
        </motion.div>

        <motion.div
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.5 }}
          className="space-y-3"
        >
          <motion.button
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            onClick={onSendWhatsApp}
            className="w-full px-6 py-4 bg-[#25D366] text-white rounded-2xl shadow-xl hover:shadow-[#25D366]/20 transition-all duration-300 flex items-center justify-center gap-3"
          >
            <MessageCircle className="w-5 h-5" />
            <span>Enviar pedido por WhatsApp</span>
          </motion.button>

          <motion.button
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            onClick={onBackToHome}
            className="w-full px-6 py-4 bg-secondary text-secondary-foreground rounded-2xl shadow-lg hover:bg-accent transition-all duration-300 flex items-center justify-center gap-3"
          >
            <Home className="w-5 h-5" />
            <span>Volver al inicio</span>
          </motion.button>
        </motion.div>
      </div>
    </motion.div>
  );
}
