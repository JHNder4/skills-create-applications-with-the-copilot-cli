import { motion } from "motion/react";
import { Plus, Minus, ShoppingCart } from "lucide-react";

export interface Product {
  id: string;
  name: string;
  price: number;
  image?: string;
}

interface ProductCatalogProps {
  products: Product[];
  cart: Record<string, number>;
  onUpdateCart: (productId: string, quantity: number) => void;
  onContinue: () => void;
}

export function ProductCatalog({ products, cart, onUpdateCart, onContinue }: ProductCatalogProps) {
  const totalItems = Object.values(cart).reduce((sum, qty) => sum + qty, 0);

  return (
    <motion.div
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: -20 }}
      className="min-h-screen bg-background p-6 pb-32"
    >
      <div className="max-w-2xl mx-auto">
        <motion.div
          initial={{ y: -20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          className="mb-8"
        >
          <h2 className="text-3xl font-bold mb-2">Productos</h2>
          <p className="text-muted-foreground">Selecciona lo que deseas ordenar</p>
        </motion.div>

        <div className="grid gap-4 mb-6">
          {products.map((product, index) => {
            const quantity = cart[product.id] || 0;
            return (
              <motion.div
                key={product.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className="bg-card border border-border rounded-2xl overflow-hidden shadow-lg hover:shadow-xl hover:border-primary/50 transition-all duration-300"
              >
                {product.image && (
                  <div className="w-full h-48 overflow-hidden bg-secondary">
                    <img
                      src={product.image}
                      alt={product.name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                )}

                <div className="p-6">
                  <div className="flex items-center justify-between mb-4">
                    <div>
                      <h3 className="text-xl font-semibold mb-1">{product.name}</h3>
                      <p className="text-2xl font-bold text-primary">${product.price}</p>
                    </div>
                  </div>

                  <div className="flex items-center gap-3">
                  <motion.button
                    whileHover={{ scale: 1.1 }}
                    whileTap={{ scale: 0.9 }}
                    onClick={() => onUpdateCart(product.id, Math.max(0, quantity - 1))}
                    className="w-10 h-10 rounded-full bg-secondary text-secondary-foreground flex items-center justify-center hover:bg-accent transition-colors disabled:opacity-50"
                    disabled={quantity === 0}
                  >
                    <Minus className="w-5 h-5" />
                  </motion.button>

                  <div className="flex-1 text-center">
                    <span className="text-xl font-semibold">{quantity}</span>
                  </div>

                  <motion.button
                    whileHover={{ scale: 1.1 }}
                    whileTap={{ scale: 0.9 }}
                    onClick={() => onUpdateCart(product.id, quantity + 1)}
                    className="w-10 h-10 rounded-full bg-primary text-primary-foreground flex items-center justify-center hover:opacity-90 transition-opacity"
                  >
                    <Plus className="w-5 h-5" />
                  </motion.button>
                </div>
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>

      {totalItems > 0 && (
        <motion.div
          initial={{ y: 100 }}
          animate={{ y: 0 }}
          className="fixed bottom-0 left-0 right-0 p-6 bg-card/95 backdrop-blur-lg border-t border-border"
        >
          <div className="max-w-2xl mx-auto">
            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={onContinue}
              className="w-full px-6 py-4 bg-primary text-primary-foreground rounded-2xl shadow-xl hover:shadow-primary/20 transition-all duration-300 flex items-center justify-center gap-3"
            >
              <ShoppingCart className="w-5 h-5" />
              <span>Ver carrito ({totalItems} {totalItems === 1 ? 'producto' : 'productos'})</span>
            </motion.button>
          </div>
        </motion.div>
      )}
    </motion.div>
  );
}
