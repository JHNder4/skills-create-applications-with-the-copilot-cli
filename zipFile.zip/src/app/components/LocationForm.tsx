import { motion } from "motion/react";
import { ArrowLeft, MapPin, Navigation } from "lucide-react";
import { useState } from "react";

interface LocationFormProps {
  onBack: () => void;
  onContinue: (address: string) => void;
}

export function LocationForm({ onBack, onContinue }: LocationFormProps) {
  const [address, setAddress] = useState("");
  const [useCurrentLocation, setUseCurrentLocation] = useState(false);

  const handleShareLocation = async () => {
    try {
      if (!("geolocation" in navigator)) {
        alert("Tu navegador no soporta geolocalización. Por favor, escribe tu dirección.");
        return;
      }

      setUseCurrentLocation(true);

      // Solicitar permisos primero
      try {
        const permission = await navigator.permissions.query({ name: 'geolocation' as PermissionName });

        if (permission.state === 'denied') {
          setUseCurrentLocation(false);
          alert("Permiso de ubicación denegado. Por favor, permite el acceso en la configuración de tu navegador y recarga la página.\n\nMientras tanto, puedes escribir tu dirección manualmente.");
          return;
        }
      } catch (e) {
        // Si no se puede verificar el permiso, continuamos de todas formas
        console.log("No se pudo verificar permisos:", e);
      }

      // Obtener ubicación con timeout manual
      const timeoutId = setTimeout(() => {
        setUseCurrentLocation(false);
        alert("La solicitud de ubicación tomó demasiado tiempo.\n\nPor favor, escribe tu dirección manualmente.");
      }, 10000);

      navigator.geolocation.getCurrentPosition(
        (position) => {
          clearTimeout(timeoutId);
          const { latitude, longitude } = position.coords;
          const locationText = `📍 Ubicación GPS\nLat: ${latitude.toFixed(6)}, Lng: ${longitude.toFixed(6)}`;
          setAddress(locationText);
          setUseCurrentLocation(false);
        },
        (error) => {
          clearTimeout(timeoutId);
          setUseCurrentLocation(false);

          let errorMessage = "No se pudo obtener la ubicación.\n\n";

          if (error && typeof error.code === 'number') {
            switch (error.code) {
              case 1: // PERMISSION_DENIED
                errorMessage += "Permiso denegado. Por favor, permite el acceso a tu ubicación.";
                break;
              case 2: // POSITION_UNAVAILABLE
                errorMessage += "Información de ubicación no disponible.";
                break;
              case 3: // TIMEOUT
                errorMessage += "La solicitud excedió el tiempo de espera.";
                break;
              default:
                errorMessage += "Error desconocido al obtener ubicación.";
            }
          } else {
            errorMessage += "Error al acceder a la geolocalización.";
          }

          errorMessage += "\n\nPuedes escribir tu dirección manualmente abajo.";
          alert(errorMessage);
        },
        {
          enableHighAccuracy: false,
          timeout: 8000,
          maximumAge: 60000
        }
      );
    } catch (error) {
      setUseCurrentLocation(false);
      console.error("Error en geolocalización:", error);
      alert("Ocurrió un error al intentar obtener tu ubicación.\n\nPor favor, escribe tu dirección manualmente.");
    }
  };

  const handleContinue = () => {
    if (address.trim()) {
      onContinue(address.trim());
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: -20 }}
      className="min-h-screen bg-background p-6"
    >
      <div className="max-w-2xl mx-auto">
        <motion.button
          whileHover={{ x: -5 }}
          whileTap={{ scale: 0.95 }}
          onClick={onBack}
          className="mb-6 flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors"
        >
          <ArrowLeft className="w-5 h-5" />
          <span>Volver</span>
        </motion.button>

        <motion.div
          initial={{ y: -20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          className="mb-8"
        >
          <h2 className="text-3xl font-bold mb-2">Ubicación</h2>
          <p className="text-muted-foreground">¿Dónde te enviamos tu pedido?</p>
        </motion.div>

        <motion.button
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
          onClick={handleShareLocation}
          disabled={useCurrentLocation}
          className="w-full mb-6 px-6 py-5 bg-gradient-to-r from-primary to-primary/80 text-primary-foreground rounded-2xl shadow-xl hover:shadow-primary/20 transition-all duration-300 flex items-center justify-center gap-3 disabled:opacity-50"
        >
          <Navigation className="w-5 h-5" />
          <span>{useCurrentLocation ? "Obteniendo ubicación..." : "Compartir mi ubicación"}</span>
        </motion.button>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.2 }}
          className="mb-8 text-center text-muted-foreground"
        >
          o
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="mb-8"
        >
          <label className="block mb-3 text-muted-foreground">
            Escribe tu dirección
          </label>
          <textarea
            value={address}
            onChange={(e) => setAddress(e.target.value)}
            placeholder="Calle, número, colonia, referencias..."
            rows={4}
            className="w-full px-4 py-4 bg-card border border-border rounded-2xl focus:outline-none focus:ring-2 focus:ring-primary/50 transition-all resize-none"
          />
        </motion.div>

        <motion.button
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.4 }}
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
          onClick={handleContinue}
          disabled={!address.trim()}
          className="w-full px-6 py-4 bg-primary text-primary-foreground rounded-2xl shadow-xl hover:shadow-primary/20 transition-all duration-300 flex items-center justify-center gap-3 disabled:opacity-50 disabled:cursor-not-allowed"
        >
          <MapPin className="w-5 h-5" />
          <span>Confirmar pedido</span>
        </motion.button>
      </div>
    </motion.div>
  );
}
