import { useState } from "react";
import { AnimatePresence } from "motion/react";
import { HomeScreen } from "./components/HomeScreen";
import { ProductCatalog, Product } from "./components/ProductCatalog";
import { Cart } from "./components/Cart";
import { LocationForm } from "./components/LocationForm";
import { OrderConfirmation } from "./components/OrderConfirmation";

type Screen = "home" | "products" | "cart" | "location" | "confirmation";

const PRODUCTS: Product[] = [
  {
    id: "estrella",
    name: "Estrella",
    price: 130,
    image: "https://images.unsplash.com/photo-1624631697312-3cfd942961ec?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=400"
  },
  {
    id: "estrella-premium",
    name: "Estrella Premium",
    price: 500,
    image: "https://images.unsplash.com/photo-1640651664038-c1a0e134fa85?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=400"
  },
  {
    id: "te-preparado",
    name: "Té preparado",
    price: 50,
    image: "https://images.unsplash.com/photo-1571934811356-5cc061b6821f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=400"
  },
  {
    id: "brillo",
    name: "Brillo",
    price: 130,
    image: "https://images.unsplash.com/photo-1777988683368-1295e7bd7ba5?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=400"
  },
];

export default function App() {
  const [currentScreen, setCurrentScreen] = useState<Screen>("home");
  const [cart, setCart] = useState<Record<string, number>>({});
  const [address, setAddress] = useState("");

  const handleUpdateCart = (productId: string, quantity: number) => {
    setCart(prev => {
      if (quantity === 0) {
        const newCart = { ...prev };
        delete newCart[productId];
        return newCart;
      }
      return { ...prev, [productId]: quantity };
    });
  };

  const handleSendWhatsApp = () => {
    const cartItems = PRODUCTS.map(product => ({
      ...product,
      quantity: cart[product.id] || 0,
    })).filter(item => item.quantity > 0);

    const total = cartItems.reduce((sum, item) => sum + item.price * item.quantity, 0);

    let message = "*🛍️ Nuevo Pedido - Thepoint*\n\n";
    message += "*Productos:*\n";

    cartItems.forEach(item => {
      message += `• ${item.name} x${item.quantity} - $${item.price * item.quantity}\n`;
    });

    message += `\n*Total: $${total}*\n\n`;
    message += `*📍 Dirección de entrega:*\n${address}\n\n`;
    message += `*💵 Método de pago:* Efectivo`;

    const phoneNumber = "5213411674625";
    const whatsappUrl = `https://wa.me/${phoneNumber}?text=${encodeURIComponent(message)}`;

    window.open(whatsappUrl, "_blank");
  };

  const handleBackToHome = () => {
    setCurrentScreen("home");
    setCart({});
    setAddress("");
  };

  return (
    <div className="size-full dark">
      <AnimatePresence mode="wait">
        {currentScreen === "home" && (
          <HomeScreen
            key="home"
            onStartOrder={() => setCurrentScreen("products")}
          />
        )}

        {currentScreen === "products" && (
          <ProductCatalog
            key="products"
            products={PRODUCTS}
            cart={cart}
            onUpdateCart={handleUpdateCart}
            onContinue={() => setCurrentScreen("cart")}
          />
        )}

        {currentScreen === "cart" && (
          <Cart
            key="cart"
            products={PRODUCTS}
            cart={cart}
            onBack={() => setCurrentScreen("products")}
            onContinue={() => setCurrentScreen("location")}
          />
        )}

        {currentScreen === "location" && (
          <LocationForm
            key="location"
            onBack={() => setCurrentScreen("cart")}
            onContinue={(addr) => {
              setAddress(addr);
              setCurrentScreen("confirmation");
            }}
          />
        )}

        {currentScreen === "confirmation" && (
          <OrderConfirmation
            key="confirmation"
            products={PRODUCTS}
            cart={cart}
            address={address}
            onSendWhatsApp={handleSendWhatsApp}
            onBackToHome={handleBackToHome}
          />
        )}
      </AnimatePresence>
    </div>
  );
}